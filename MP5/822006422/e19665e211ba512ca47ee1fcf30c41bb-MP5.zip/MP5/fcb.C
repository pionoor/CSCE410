#include "fcb.H"

fcb::fcb(int _file_id)
{

    file_id = _file_id;
    first_block = -1;
}



int fcb::getId()
{
	return file_id;
}

void fcb::setId(int _file_id)
{
	file_id = _file_id;
}

char * fcb::getOwner()
{
	return owner;
}

void fcb::setOwner(char *str)
{
	memcpy(owner, str, 20);
}

bool * fcb::getPermissions()
{
	return permissions;
}

void fcb::setPermissions(bool *str)
{
	memcpy(permissions, str, 3);
}

int fcb::getFileSize()
{
	return fileSize;
}

void fcb::setFileSize(int size)
{
	fileSize = size;
}

int fcb::GetFirstBlock(){
    return first_block;
}

void fcb::SetFirstBlock(int block){
    first_block = block;
}

int fcb::getFCBSize(){
    return 0;
}

