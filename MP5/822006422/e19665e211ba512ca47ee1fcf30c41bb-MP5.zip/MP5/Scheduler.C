#include "Scheduler.H"
#include "blocking_disk.H"
#include "assert.H"

/*Costructor*/
Scheduler::Scheduler()
{
}


void Scheduler::yield()
{

   if(SYSTEM_BLOCK_DISK->is_op_disk() && SYSTEM_BLOCK_DISK->is_disk_ready())    //is operating on disk
   {
    
      Thread *next = SYSTEM_BLOCK_DISK->dequeue_thread();
      if(next == NULL)
      {
         Console::puts("\n Error! DiskQueue empty!!");
         assert(false);
      }
      else
      {
         SYSTEM_BLOCK_DISK->reset_op_disk();
         Thread::dispatch_to(next);
         return;
      }
   }
   else if (!SYSTEM_BLOCK_DISK->is_op_disk()) //disk is free
   {
      struct disk_operation* new_op = SYSTEM_BLOCK_DISK->dequeue_operation();
      if(new_op != NULL)
      {
         SYSTEM_BLOCK_DISK->issue_operation(new_op->current_op, new_op->block_no);
         SYSTEM_BLOCK_DISK->set_op_disk();
      }
      else
      {
         Console::puts("\n The disk queue is empty");         
         for(int j=0; j<2000000 * 5; ++j);
      }
   }

   Thread *next = ReadyQueue.dequeue();
   if (next != NULL)
   {
         Thread::dispatch_to(next);
   }
   else
   {
      Console::puts("Error encountered!!");
      assert(false);
   }
}

void Scheduler::resume(Thread * _thread)
{
   ReadyQueue.enqueue(_thread);
}



void Scheduler::add(Thread * _thread)
{
   ReadyQueue.enqueue(_thread);
}
  
void Scheduler::terminate(Thread * _thread)
{
   delete _thread;
}

